var config = {
    corpId: "ww2460c9d1886951ff",
    corpSecret: "H0FnPR_xIE397RPx7uiyFsmF_nfvCKB2pJJCPjxT_nU",
    agentid: 1000002
};
export default config;