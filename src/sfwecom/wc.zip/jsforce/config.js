var config = {
    loginUrl: "https://d5h00000523kreay--fsrdev001.sandbox.my.salesforce.com/",
    userId: "hr-h8pk@force.com.fsrdev001",
    pwd: "fsrSBdev001!NNdYTK3MVsqiNvy8rAJMdVcW"
};
export default config;